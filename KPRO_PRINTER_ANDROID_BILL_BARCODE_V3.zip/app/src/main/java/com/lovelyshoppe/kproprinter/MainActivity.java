package com.lovelyshoppe.kproprinter;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final int REQ_BT = 501;
    private BluetoothAdapter adapter;
    private final List<BluetoothDevice> devices = new ArrayList<>();
    private Spinner printerSpinner, labelSizeSpinner;
    private TextView status, labelPreview;
    private EditText codeInput, priceInput, shopInput;
    private BluetoothSocket socket;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); adapter=BluetoothAdapter.getDefaultAdapter(); buildUi(); ensurePermissionAndLoad();
    }
    private TextView text(String s,int sp,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(Color.BLACK);if(bold)v.setTypeface(null,android.graphics.Typeface.BOLD);v.setPadding(0,12,0,12);return v;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}
    private EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);return e;}

    private void buildUi(){
        ScrollView sv=new ScrollView(this); LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(36,48,36,36);sv.addView(box);setContentView(sv);
        TextView title=text("KPRO Printer",28,true);title.setGravity(Gravity.CENTER);box.addView(title);
        TextView sub=text("Bill + Barcode Label • Bluetooth Direct",14,false);sub.setGravity(Gravity.CENTER);box.addView(sub);
        box.addView(text("Paired Bluetooth Printer",14,true)); printerSpinner=new Spinner(this);box.addView(printerSpinner,new LinearLayout.LayoutParams(-1,120));
        Button refresh=button("Refresh Paired Printers");box.addView(refresh);refresh.setOnClickListener(v->ensurePermissionAndLoad());
        Button connect=button("Connect Printer");box.addView(connect);connect.setOnClickListener(v->connectSelected());
        box.addView(text("BILL / RECEIPT",16,true)); Button test=button("Print 58mm Test Receipt");box.addView(test);test.setOnClickListener(v->printTest());
        box.addView(text("BARCODE LABEL",16,true));
        shopInput=input("Shop name (e.g. Lovely Shoppe)");box.addView(shopInput);codeInput=input("Product code / barcode");box.addView(codeInput);priceInput=input("Price (optional)");box.addView(priceInput);
        labelSizeSpinner=new Spinner(this);labelSizeSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"35 x 22 mm","50 x 30 mm"}));box.addView(labelSizeSpinner);
        Button preview=button("Preview Barcode Label");box.addView(preview);preview.setOnClickListener(v->previewLabel());
        labelPreview=text("Label preview will appear here",15,true);labelPreview.setGravity(Gravity.CENTER);labelPreview.setBackgroundColor(Color.rgb(245,245,245));labelPreview.setPadding(20,30,20,30);box.addView(labelPreview,new LinearLayout.LayoutParams(-1,-2));
        Button label=button("Print Barcode Label");box.addView(label);label.setOnClickListener(v->printLabel());
        Button disconnect=button("Disconnect");box.addView(disconnect);disconnect.setOnClickListener(v->disconnect());
        status=text("Status: Ready",14,true);box.addView(status);
        box.addView(text("Receipt uses ESC/POS. Barcode label uses TSPL commands for BT-58L label mode. Change the printer to the required mode before printing.",13,false));
    }

    private boolean hasBtPermission(){return Build.VERSION.SDK_INT<31||checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;}
    private void ensurePermissionAndLoad(){if(Build.VERSION.SDK_INT>=31&&!hasBtPermission()){requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);return;}loadPaired();}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_BT&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)loadPaired();else setStatus("Bluetooth permission required");}
    private void loadPaired(){if(adapter==null){setStatus("Bluetooth not supported");return;}if(!adapter.isEnabled()){setStatus("Turn ON Bluetooth, pair printer, then Refresh");return;}try{devices.clear();for(BluetoothDevice d:adapter.getBondedDevices())devices.add(d);Collections.sort(devices,(a,b)->String.valueOf(a.getName()).compareToIgnoreCase(String.valueOf(b.getName())));List<String> names=new ArrayList<>();for(BluetoothDevice d:devices)names.add((d.getName()==null?"Bluetooth Printer":d.getName())+" • "+d.getAddress());printerSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));setStatus(devices.isEmpty()?"No paired printer. Pair printer in Android Settings first.":"Found "+devices.size()+" paired device(s)");}catch(SecurityException e){setStatus("Bluetooth permission missing");}}
    private BluetoothDevice selected(){int i=printerSpinner.getSelectedItemPosition();return i>=0&&i<devices.size()?devices.get(i):null;}
    private void connectSelected(){BluetoothDevice d=selected();if(d==null){setStatus("Select a paired printer first");return;}setStatus("Connecting…");new Thread(()->{try{disconnectSocketOnly();adapter.cancelDiscovery();BluetoothSocket s=d.createRfcommSocketToServiceRecord(SPP_UUID);s.connect();socket=s;runOnUiThread(()->setStatus("Connected: "+d.getName()));}catch(Exception e){runOnUiThread(()->setStatus("Connect failed: "+e.getClass().getSimpleName()));disconnectSocketOnly();}}).start();}
    private void printTest(){if(!connected())return;new Thread(()->{try{OutputStream o=socket.getOutputStream();o.write(new byte[]{0x1B,0x40,0x1B,0x61,0x01,0x1B,0x45,0x01});o.write("KANAKKU PULLA PRO\nKPRO PRINTER TEST\n".getBytes(StandardCharsets.US_ASCII));o.write(new byte[]{0x1B,0x45,0x00,0x1B,0x61,0x00});o.write("--------------------------------\n58mm RECEIPT TEST\nTEST PRINT SUCCESS\n\n\n".getBytes(StandardCharsets.US_ASCII));o.flush();runOnUiThread(()->setStatus("Receipt test sent ✓"));}catch(Exception e){runOnUiThread(()->setStatus("Receipt print failed: "+e.getClass().getSimpleName()));}}).start();}
    private void previewLabel(){String code=codeInput.getText().toString().trim();if(code.isEmpty())code="ABC123";String shop=shopInput.getText().toString().trim();if(shop.isEmpty())shop="KANAKKU PULLA PRO";String price=priceInput.getText().toString().trim();labelPreview.setText(shop+"\n|||| ||| |||| | |||\n"+code+(price.isEmpty()?"":"\nRs. "+price)+"\n"+labelSizeSpinner.getSelectedItem());setStatus("Label preview ready (printer not required)");}
    private void printLabel(){if(!connected())return;String code=codeInput.getText().toString().trim();if(code.isEmpty()){setStatus("Enter product code first");return;}String shop=shopInput.getText().toString().trim();if(shop.isEmpty())shop="KANAKKU PULLA PRO";String price=priceInput.getText().toString().trim();boolean small=labelSizeSpinner.getSelectedItemPosition()==0;int w=small?35:50,h=small?22:30;StringBuilder tspl=new StringBuilder();tspl.append("SIZE ").append(w).append(" mm,").append(h).append(" mm\r\n");tspl.append("GAP 2 mm,0 mm\r\nCLS\r\n");tspl.append("TEXT 20,10,\"2\",0,1,1,\"").append(clean(shop)).append("\"\r\n");tspl.append("BARCODE 20,45,\"128\",55,1,0,2,2,\"").append(clean(code)).append("\"\r\n");if(!price.isEmpty())tspl.append("TEXT 20,115,\"2\",0,1,1,\"Rs. ").append(clean(price)).append("\"\r\n");tspl.append("PRINT 1,1\r\n");final byte[] data=tspl.toString().getBytes(StandardCharsets.US_ASCII);new Thread(()->{try{OutputStream o=socket.getOutputStream();o.write(data);o.flush();runOnUiThread(()->setStatus("Barcode label sent ✓ Check printer"));}catch(Exception e){runOnUiThread(()->setStatus("Label print failed: "+e.getClass().getSimpleName()));}}).start();}
    private String clean(String s){return s.replace("\"","").replace("\r"," ").replace("\n"," ");}
    private boolean connected(){if(socket==null||!socket.isConnected()){setStatus("Connect printer first");return false;}return true;}
    private void setStatus(String s){runOnUiThread(()->status.setText("Status: "+s));}
    private void disconnect(){disconnectSocketOnly();setStatus("Disconnected");}
    private void disconnectSocketOnly(){try{if(socket!=null)socket.close();}catch(Exception ignored){}socket=null;}
    @Override protected void onDestroy(){disconnectSocketOnly();super.onDestroy();}
}
