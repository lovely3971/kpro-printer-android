# KPRO Printer Android V3 — Bill + Barcode

One Android Bluetooth printer bridge for Kanakku Pulla PRO.

- 58mm ESC/POS receipt test
- Barcode label preview without a printer
- Direct TSPL barcode label command output
- 35×22 mm and 50×30 mm label presets
- Bluetooth Classic SPP/RFCOMM transport

Physical label printing still requires a compatible printer test because printer firmware/mode may vary.
