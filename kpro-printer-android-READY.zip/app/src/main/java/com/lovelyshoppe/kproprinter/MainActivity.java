package com.lovelyshoppe.kproprinter;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final int REQ_BT = 501;
    private BluetoothAdapter adapter;
    private final List<BluetoothDevice> devices = new ArrayList<>();
    private Spinner printerSpinner;
    private TextView status;
    private BluetoothSocket socket;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        adapter = BluetoothAdapter.getDefaultAdapter();
        buildUi();
        ensurePermissionAndLoad();
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView v = new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(Color.BLACK);
        if (bold) v.setTypeface(null, android.graphics.Typeface.BOLD); v.setPadding(0,12,0,12); return v;
    }

    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); return b;
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(36,48,36,36);
        sv.addView(box); setContentView(sv);
        TextView title=text("KPRO Printer",28,true); title.setGravity(Gravity.CENTER); box.addView(title);
        TextView sub=text("Android Bluetooth Receipt Bridge • 58mm",14,false); sub.setGravity(Gravity.CENTER); box.addView(sub);
        box.addView(text("Paired Bluetooth Printer",14,true));
        printerSpinner = new Spinner(this); box.addView(printerSpinner, new LinearLayout.LayoutParams(-1,120));
        Button refresh=button("Refresh Paired Printers"); box.addView(refresh); refresh.setOnClickListener(v->ensurePermissionAndLoad());
        Button connect=button("Connect Printer"); box.addView(connect); connect.setOnClickListener(v->connectSelected());
        Button test=button("Print 58mm Test Receipt"); box.addView(test); test.setOnClickListener(v->printTest());
        Button disconnect=button("Disconnect"); box.addView(disconnect); disconnect.setOnClickListener(v->disconnect());
        status=text("Status: Ready",14,true); box.addView(status);
        box.addView(text("Before testing: Android Settings → Bluetooth → pair BT-58L/BT-58TSC first. PIN if asked: 0000. Printer must be in Receipt Mode.",13,false));
    }

    private boolean hasBtPermission() {
        return Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }
    private void ensurePermissionAndLoad() {
        if (Build.VERSION.SDK_INT >= 31 && !hasBtPermission()) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT); return;
        }
        loadPaired();
    }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r,p,g); if(r==REQ_BT && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) loadPaired();
        else setStatus("Bluetooth permission required");
    }

    private void loadPaired() {
        if (adapter == null) { setStatus("Bluetooth not supported on this phone"); return; }
        if (!adapter.isEnabled()) { setStatus("Turn ON Bluetooth, pair printer, then Refresh"); return; }
        try {
            devices.clear(); List<String> names=new ArrayList<>();
            for(BluetoothDevice d: adapter.getBondedDevices()) { devices.add(d); names.add((d.getName()==null?"Bluetooth Printer":d.getName())+"\n"+d.getAddress()); }
            Collections.sort(devices, (a,b)->String.valueOf(a.getName()).compareToIgnoreCase(String.valueOf(b.getName())));
            names.clear(); for(BluetoothDevice d:devices) names.add((d.getName()==null?"Bluetooth Printer":d.getName())+"  •  "+d.getAddress());
            printerSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
            setStatus(devices.isEmpty()?"No paired printer. Pair BT-58L in Android Settings first.":"Found "+devices.size()+" paired device(s)");
        } catch(SecurityException e){ setStatus("Bluetooth permission missing"); }
    }

    private BluetoothDevice selected() { int i=printerSpinner.getSelectedItemPosition(); return i>=0 && i<devices.size()?devices.get(i):null; }
    private void connectSelected() {
        BluetoothDevice d=selected(); if(d==null){setStatus("Select a paired printer first");return;}
        setStatus("Connecting to "+d.getName()+"…");
        new Thread(() -> {
            try {
                disconnectSocketOnly(); adapter.cancelDiscovery();
                BluetoothSocket s=d.createRfcommSocketToServiceRecord(SPP_UUID); s.connect(); socket=s;
                runOnUiThread(()->setStatus("Connected: "+d.getName()));
            } catch(Exception e){ runOnUiThread(()->setStatus("Connect failed: "+e.getClass().getSimpleName()+" • "+safe(e.getMessage()))); disconnectSocketOnly(); }
        }).start();
    }

    private void printTest() {
        if(socket==null || !socket.isConnected()){ setStatus("Connect printer first"); return; }
        setStatus("Sending test receipt…");
        new Thread(() -> {
            try {
                OutputStream o=socket.getOutputStream();
                o.write(new byte[]{0x1B,0x40}); // ESC @ init
                o.write(new byte[]{0x1B,0x61,0x01}); // center
                o.write(new byte[]{0x1B,0x45,0x01}); // bold on
                o.write("KANAKKU PULLA PRO\n".getBytes(StandardCharsets.US_ASCII));
                o.write(new byte[]{0x1B,0x45,0x00});
                o.write("KPRO PRINTER TEST\n".getBytes(StandardCharsets.US_ASCII));
                o.write(new byte[]{0x1B,0x61,0x00});
                o.write("--------------------------------\n".getBytes(StandardCharsets.US_ASCII));
                o.write("Printer : Bluetooth Thermal\n".getBytes(StandardCharsets.US_ASCII));
                o.write("Paper   : 58mm / 2 inch\n".getBytes(StandardCharsets.US_ASCII));
                o.write("Mode    : Receipt / ESC-POS\n".getBytes(StandardCharsets.US_ASCII));
                o.write("--------------------------------\n".getBytes(StandardCharsets.US_ASCII));
                o.write("TEST PRINT SUCCESS\n\n\n".getBytes(StandardCharsets.US_ASCII));
                o.flush();
                runOnUiThread(()->setStatus("Test data sent ✓ Check printer"));
            } catch(Exception e){ runOnUiThread(()->setStatus("Print failed: "+e.getClass().getSimpleName()+" • "+safe(e.getMessage()))); }
        }).start();
    }

    private String safe(String s){ return s==null?"":s; }
    private void setStatus(String s){ runOnUiThread(()->status.setText("Status: "+s)); }
    private void disconnect(){ disconnectSocketOnly(); setStatus("Disconnected"); }
    private void disconnectSocketOnly(){ try{ if(socket!=null) socket.close(); }catch(Exception ignored){} socket=null; }
    @Override protected void onDestroy(){ disconnectSocketOnly(); super.onDestroy(); }
}
